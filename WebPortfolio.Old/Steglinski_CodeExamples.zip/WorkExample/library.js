﻿// JScript File
$().ready(function() {
/*$(".dollar").blur(function(){
    var totalVals = parseInt($("input[id*='txtQuotedRent']").val());
    $(".dollar." + $("select[id*='lstStyle'] option:selected").attr("class")).each(function(i){
        totalVals += parseInt($(this).val());
    });
    $("input[id*='lblNetRent']").html("Net Rent Rate: $" + totalVals);
});*/
$.validator.messages.required = "*";
$.validator.messages.digits = "Only numbers are allowed in this field";
  $("#frmAptComm").validate({
		rules: {
			txtQuotedRent: "required",
			txtAddress1: "required",
			txtCity: "required",
			txtState: {
				required: true,
				maxlength: 2,
				minlength: 2
			},
			txtZip: {
				required: true,
				maxlength: 5,
				minlength: 5,
				digits:true
			},
			txtPhone: {
				required: true,
				phone: true
			},
			txtEmail: {
				required: true,
				email: true
			},
			txtNumUnits: {
				required: true,
				digits: true
			},
			txtStudioHeat: {
				required: true,
				digits: true
			},
			txt1bdHeat: {
				required: true,
				digits: true
			},
			txt2bdHeat: {
				required: true,
				digits: true
			},
			txt3bdHeat: {
				required: true,
				digits: true
			},
			txtStudioElectric: {
				required: true,
				digits: true
			},
			txt1bdElectric: {
				required: true,
				digits: true
			},
			txt2bdElectric: {
				required: true,
				digits: true
			},
			txt3bdElectric: {
				required: true,
				digits: true
			},
			txtStudioWater: {
				required: true,
				digits: true
			},
			txt1bdWater: {
				required: true,
				digits: true
			},
			txt2bdWater: {
				required: true,
				digits: true
			},
			txt3bdWater: {
				required: true,
				digits: true
			},
			txtCable: {
				required: true,
				digits: true
			},
			txtWD: {
				required: true,
				digits: true
			},
			txtUpgrades: {
				required: true,
				digits: true
			},
			txtRefuse: {
				required: true,
				digits: true
			},
			txtGarden: {
				required: true,
				digits: true
			},
			txtCommunity: "required"
		},
		messages: {
			txtCommunity: "Please enter a community name",
			txtAddress1: "Please enter the community address",
			txtCity: "Please enter the community's city",
			txtState: {
			    required:"Please enter the community's state",
			    maxlength: "The state must be 2 characters long",
			    minlength: "The state must be 2 characters long"
			},
			txtZip: {
			    required: "Please enter the community's zip code",
			    maxlength: "The zip code must be 5 characters long",
			    minlength: "The zip code must be 5 characters long",
			    digits: "The zip code must only contain numbers"
			},
			txtPhone: {
				required: "Please enter the community's phone number",
				phone: "Please enter a valid phone number"
			},
			txtNumUnits: {
				required: "Please enter the number of units in the community",
				digits: "Only numbers are allowed in this field"
			},
			txtEmail: "Please enter a valid email address",
			txtQuotedRent: "Please enter a rent value"
		},
		submitHandler: function(form) {
   	        form.submit();
        }
	});
	
    createUnits();
	});
    function createUnits()
    {
        var styleValues = {"studio": new Array("Studio","Studio Deluxe"),
        "1bd":new Array("1 Bedroom","1 Bedroom Deluxe","1 Bedroom Deluxe w/Den","1 Bedroom Townhouse"),
        "2bd":new Array("2 Bedroom","2 Bedroom Deluxe","2 Bedroom Deluxe w/Den","2 Bedroom Townhouse","2 Bedroom Townhouse w/Den"),
        "3bd":new Array("3 Bedroom","3 Bedroom Deluxe","3 Bedroom Deluxe w/Den","3 Bedroom Townhouse","3 Bedroom Townhouse w/Den")};
        var bathValues = new Array("1","1.5","2","2.5","3","3.5","4");
        var leaseValues = new Array("1 Month","3 Months","6 Months","9 Months", "12 Months","24 Months");
        var startIndex = ($('#units table').length == 0) ? 1 : $('#units table').length+1

        var numUnits = $("#lstAvailStyles").val();
        if(parseInt(numUnits) >= 10) numUnits = 10;
        if(parseInt(numUnits) <= 1) numUnits = 1;
        
        if(startIndex > numUnits)
        {
            for(startIndex; startIndex > numUnits; startIndex--)
            {
                $('#unit'+startIndex).remove();
            }
        }
        else
        {
            for(var index = startIndex; index <= parseInt(numUnits); index++)
            {
                $("#units").appendDom([
                {
                    tagName:'table',
                    border: '0',
                    "class": 'para',
                    id: 'unit' + index,
                    childNodes:[{
                        tagName:'tbody',
                        childNodes: [{
                            tagName:'tr',
                            childNodes:[{
                                tagName:'td',
                                childNodes: [{
                                    tagName: 'h3',
                                    innerHTML:'Unit ' + index
                                }]
                            }]
                        }]
                    }]
                }
                ]);
                 $('#unit'+index+' tbody').appendDom([{
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                        "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Number of Apartments: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'input',
                           "class":'txtApartmentNum',
                            name:'txtApartmentNum'+index,
                            id: 'txtApartmentNum'+index,
                            size: '5',
                            maxlength: '5'
                        }]
                    }]
                }]);
                var template = [
                {
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                        "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Style: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'select',
                            name:'lstStyle'+index,
                            id:'lstStyle'+index,
                            childNodes:[]
                        }]
                    }]
                }];  
                for(i in styleValues)
                {
                    for(j in styleValues[i])
                    {
                        template[0].childNodes[1].childNodes[0].childNodes.push({
                            tagName:'option',
                            "class":i,
                            value:styleValues[i][j],
                            innerHTML:styleValues[i][j]
                        });
                    }
                }
                $('#unit'+index+' tbody').appendDom(template);
               
                $('#unit'+index+' tbody').appendDom([{
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                       "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Unit Finishes: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'input',
                           "class":'txtFinishes',
                            name:'txtFinishes'+index,
                            id: 'txtFinishes'+index,
                            size: '30',
                            maxlength: '255'
                        }]
                    }]
                }]);
                
                $('#unit'+index+' tbody').appendDom([{
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                       "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Square Footage: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'input',
                            "class":'txtFootage',
                            name:'txtFootage'+index,
                            id: 'txtFootage'+index,
                            size: '15',
                            maxlength: '20'
                        }]
                    }]
                }]);
                
                $('#unit'+index+' tbody').appendDom([{
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                       "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Quoted Rent: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'input',
                            "class":'txtQuotedRent',
                            name:'txtQuotedRent'+index,
                            id: 'txtQuotedRent'+index,
                            size: '11',
                            maxlength: '10'
                        }]
                    }]
                }]);
                
                 $('#unit'+index+' tbody').appendDom([{
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                       "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Rent Special: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'input',
                            "class":'txtRentSpecial',
                            name:'txtRentSpecial'+index,
                            id: 'txtRentSpecial'+index,
                            size: '11',
                            maxlength: '10'
                        }]
                    }]
                }]);
                
                var template = [
                {
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                       "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Number of Baths: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'select',
                            name:'lstNumBaths'+index,
                            id:'lstNumBaths'+index,
                            childNodes:[]
                        }]
                    }]
                }];
                    
                for(i in bathValues)
                {
                    template[0].childNodes[1].childNodes[0].childNodes.push({
                        tagName:'option',
                        value:bathValues[i],
                        innerHTML:bathValues[i]
                    });
                }
                
                $('#unit'+index+' tbody').appendDom(template);
                var template = [
                {
                    tagName:'tr',
                    childNodes:[{
                        tagName:'td',
                        "class": 'label',
                        childNodes: [{
                            tagName: 'p',
                            "class": 'label',
                            innerHTML:'Lease Term: '
                        }]
                    },{
                        tagName:'td',
                        childNodes: [{
                            tagName:'select',
                            name:'lstLeaseTerm'+index,
                            id:'lstLeaseTerm'+index,
                            childNodes:[]
                        }]
                    }]
                }];
                    
                for(i in leaseValues)
                {
                    template[0].childNodes[1].childNodes[0].childNodes.push({
                        tagName:'option',
                        value:leaseValues[i],
                        innerHTML:leaseValues[i]
                    });
                }
                $('#unit'+index+' tbody').appendDom(template);
                
//                $('#unit'+index+' tbody').appendDom([{
//                    tagName:'tr',
//                    colspan: '3',
//                    childNodes:[{
//                        tagName:'td',
//                        "class":'label left',
//                        style: 'padding:10px 50px; font-size:12px;text-decoration:underline',
//                        colSpan: '2',
//                        childNodes: [{
//                            tagName: 'span',
//                            id: 'lblNetRent'+index,
//                            innerHTML: 'Net Rent Rate: $'
//                        }]
//                    }]
//                }]);
                
                $('#unit'+index+' tbody').appendDom([{
                    tagName:'tr',
                    colspan: '3',
                    childNodes:[{
                        tagName:'td',
                        colSpan: '3',
                        childNodes: [{
                            tagName: 'hr',
                            width: '90%'
                        }]
                    }]
                }]);
                
                addUnitRule();
            }
        }

    }
    function addUnitRule()
    {
    //alert($("input[id*='txtQuotedRent']").length);
        $("input[id*='txtQuotedRent']").each(function(i){
            $(this).rules("add", {  
                required:true,
                number:true,
                messages:{
                    required:"Please enter a rent value",
                    number:"Only numbers and decimals are allowed in this field"
                } 
              }
        )});
        $("input[id*='txtApartmentNum']").each(function(i){
            $(this).rules("add", {  
                required:true,
                digits:true,
                messages:{
                    required:"Please enter the apartment number",
                    digits:"Only numbers are allowed in this field"
                } 
            }
        )});
        $("input[id*='txtFootage']").each(function(i){
            $(this).rules("add", {  
                required:true,
                messages:{
                    required:"Please enter the units square footage"
                } 
            }
        )});
        $("input[id*='txtRentSpecial']").each(function(i){
            $(this).rules("add", { 
                number:true,
                messages:{
                    number:"Only numbers and decimals are allowed in this field"
                } 
            }
        )});
    }


﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using WebPortfolio.dataaccess;

namespace WebPortfolio
{
    public partial class _Default : System.Web.UI.Page
    {
        public Image imgThumbPreview; 
        public DataRetriever myDr = new DataRetriever();

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                string sectionUrl = "";
                try
                {
                    //BIND TITLE IMAGE
                    sectionUrl = myDr.GetSectionImage(Request.QueryString.Get("s"));
                }
                catch (Exception evt)
                {
                    //IF I CANNOT FIND THE SECTION IN THE DATABASE, DEFAULT TO THE WELCOME URL
                    //lblError.Text = evt.Message;
                    sectionUrl = "welcome.png";
                }

                sectionImage.ImageUrl += sectionUrl;
            }
            
        }
    }
}
